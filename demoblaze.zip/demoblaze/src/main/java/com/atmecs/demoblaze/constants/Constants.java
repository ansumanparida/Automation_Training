package com.atmecs.demoblaze.constants;

public class Constants {
	public static final String testdata_file = "D:\\SDET Certification\\Automation_trainning\\Automation_Training\\demoblaze\\src\\test\\resources\\demoblaze\\testData.Properties";
	public static final String locators_file = "D:\\SDET Certification\\Automation_trainning\\Automation_Training\\demoblaze\\src\\test\\resources\\demoblaze\\locators.Properties";
	public static final String chrome_path = "D:\\SDET Certification\\Automation_trainning\\Automation_Training\\demoblaze\\lib\\chromedriver.exe";
	public static final String firefox_path="D:\\SDET Certification\\Automation_trainning\\Automation_Training\\demoblaze\\lib\\geckodriver.exe";

}
